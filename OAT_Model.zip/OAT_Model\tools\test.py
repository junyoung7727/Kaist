import torch

print(torch.tensor(1).unsqueeze(0))